
<html>
<head>
<title>User Login</title>
<link rel="stylesheet" href="index.css">
</head>
<body>
<div class="quizen">

      
        <img  src="Header-Homepage_Groenste-Pure_Energie__FocusFillWzE5MjAsODc4LCJ5IiwxXQ_CompressedW10.jpg" style="width:100%">
        <div class="container">
        
        </div>
      </div>
      
      <div class="quizen2">
       
          <img src="NLE-Energie-LOGO.jpg" style="width:100%">
        <div class="container">
      
        </div>
      </div>
	
	<div class="tekst">
        <P id="hallo">Op deze pagina ziet u vooral informatie over energie en besparing.
Hier ga ik u uitleggen wat u allemaal kan doen op onze website.
Als u ingelogd bent met uw account kunt u op de overzicht pagina zien hoeveel gas u gebruikt en elektriciteit. U krijgt ook een mooi overzicht van het gebruik de afgelopen tijd.
Wat u nog meer kunt doen op de overzicht pagina is een vergelijking met andere huishoudens en woningtypes van deze maand.
Als u een leverancier bent heeft u nog een invoer pagina daar kunt u de gegevens controleren en kijken of alles goed is. De leverancier heeft ook een overzicht pagina daar kan die nieuwe klanten aanmaken en heeft de registraties van alle klanten.

        </P>
        
      
        </div>
      
        

	 <div class="navbar">
   <h1>ENERGIEOVERZICHT HUISHOUDENS</h1>
  <a class="active" href="index.php">Index</a> 
  <a href="Overzicht.php">overzicht</a> 
  <a href="toevoegForm.php">invoer</a> 
  <a href="admin.php">admin</a> 
  <a href="logout.php">Log uit</a>
</div>
	
	
</body>
</html>

