<?php 
    $host = "localhost";
    $username = "dbbaazzgg";
    $password = "neknek";
    $database = "86890_database1";

    $db_connect = mysqli_connect($host, $username, $password, $database);
?>